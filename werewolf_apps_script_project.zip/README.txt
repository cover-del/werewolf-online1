README - Werewolf (Apps Script + Frontend ZIP)
===============================================
Contents:
- Code.gs            (Apps Script backend)
- index.html         (Apps Script HTML file - loads style & script)
- style.html         (CSS)
- script.html        (frontend JS)

How to deploy:
1. Go to https://script.google.com/ and create a new Apps Script project.
2. Create files with the same names above and paste contents.
   - Code.gs -> backend
   - index.html -> HTML (select "HTML" file, name it index)
   - style.html -> HTML file, name style
   - script.html -> HTML file, name script
3. Save, then click "Deploy" -> "New deployment" -> select "Web app".
   - Execute as: Me (your account)
   - Who has access: Anyone (or Anyone with link)
4. Deploy and authorize (Drive permission required for avatar uploads).
5. Open the provided web app URL (share with friends).

Notes:
- This demo stores rooms in PropertiesService. For production, consider using Spreadsheet or Firestore.
- Avatars are stored in your Drive under folder "Werewolf_Avatars".
- By design, players (including host) only see their own role until game end; after game end roles are revealed.
